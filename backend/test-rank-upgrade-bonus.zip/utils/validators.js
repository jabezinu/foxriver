// Phone number validation for Ethiopia (+251)
exports.isValidEthiopianPhone = (phone) => {
    const phoneRegex = /^\+251[79]\d{8}$/;
    return phoneRegex.test(phone);
};

// Allowed withdrawal amounts in ETB
exports.ALLOWED_WITHDRAWAL_AMOUNTS = [
    100, 200, 3600, 9900, 30000, 45000, 60000, 90000, 120000, 180000
];

// Validate deposit amount dynamically - ONLY membership tier prices
exports.isValidDepositAmount = async (amount) => {
    const Membership = require('../models/Membership');
    const { Op } = require('sequelize');
    
    const memberships = await Membership.findAll({
        attributes: ['price'],
        where: {
            price: { [Op.gt]: 0 } // Exclude free memberships (Intern)
        }
    });
    
    // Extract prices and convert to numbers - ONLY membership prices
    const allowedAmounts = memberships.map(m => parseFloat(m.price)).sort((a, b) => a - b);
    
    return allowedAmounts.includes(Number(amount));
};

// Validate withdrawal amount
exports.isValidWithdrawalAmount = (amount) => {
    return exports.ALLOWED_WITHDRAWAL_AMOUNTS.includes(Number(amount));
};

// Validate transaction password (6-digit numeric)
exports.isValidTransactionPassword = (password) => {
    const passwordRegex = /^\d{6}$/;
    return passwordRegex.test(password);
};

// Generate unique order ID for deposits
exports.generateOrderId = () => {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000);
    return `ORD${timestamp}${random}`;
};

// Generate unique invitation code
exports.generateInvitationCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = 'FXR';
    for (let i = 0; i < 8; i++) {
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
};
