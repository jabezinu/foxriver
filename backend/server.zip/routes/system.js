const express = require('express');
const router = express.Router();
const { getSystemSettings, updateSystemSettings } = require('../controllers/systemSettingsController');
const { protect, adminOnly, checkPermission } = require('../middlewares/auth');
const { SystemSetting } = require('../models');

// @desc    Get public system settings
// @route   GET /api/system/settings
// @access  Public
router.get('/settings', async (req, res) => {
    try {
        let settings = await SystemSetting.findOne();

        if (!settings) {
            settings = await SystemSetting.create({});
        }

        res.status(200).json({
            success: true,
            frontendDisabled: settings.frontendDisabled || false,
            settings: {
                commissionPercentA: settings.commissionPercentA,
                commissionPercentB: settings.commissionPercentB,
                commissionPercentC: settings.commissionPercentC,
                upgradeCommissionPercentA: settings.upgradeCommissionPercentA,
                upgradeCommissionPercentB: settings.upgradeCommissionPercentB,
                upgradeCommissionPercentC: settings.upgradeCommissionPercentC,
                salaryDirect10Threshold: settings.salaryDirect10Threshold,
                salaryDirect10Amount: settings.salaryDirect10Amount,
                salaryDirect15Threshold: settings.salaryDirect15Threshold,
                salaryDirect15Amount: settings.salaryDirect15Amount,
                salaryDirect20Threshold: settings.salaryDirect20Threshold,
                salaryDirect20Amount: settings.salaryDirect20Amount,
                salaryNetwork40Threshold: settings.salaryNetwork40Threshold,
                salaryNetwork40Amount: settings.salaryNetwork40Amount,
                videoPaymentAmount: settings.videoPaymentAmount,
                videosPerDay: settings.videosPerDay,
                videoWatchTimeRequired: settings.videoWatchTimeRequired,
                tasksDisabled: settings.tasksDisabled || false,
                frontendDisabled: settings.frontendDisabled || false,
                rankUpgradeBonusPercent: settings.rankUpgradeBonusPercent || 15.00
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message || 'Server error'
        });
    }
});

// Admin routes
router.get('/admin/settings', protect, adminOnly, checkPermission('manage_system_settings'), getSystemSettings);
router.put('/admin/settings', protect, adminOnly, checkPermission('manage_system_settings'), updateSystemSettings);

module.exports = router;
